# المعمارية التقنية — مدرسة السلام

## 1. القرار المعماري
اعتماد تطبيق ويب تقدمي PWA بواجهة Vanilla HTML/CSS/JavaScript، وخادم API مركزي، وقاعدة PostgreSQL. يُغلّف تطبيق الويب لاحقاً لتطبيق Android باستخدام Capacitor أو آلية WebView موثوقة بعد اكتمال واختبار PWA.

**RealmDB ليست قاعدة البيانات الرئيسية لهذا المشروع.** Realm JS يدعم React Native وNode.js وElectron، ولا يدعم المتصفح العادي مباشرة. كما أن Device Sync القديم تم إيقافه. يمكن إعادة تقييم Realm كقاعدة محلية فقط إذا انتقل التطبيق إلى بيئة أصلية مدعومة، لكن ذلك لا يلغي الحاجة إلى خادم مركزي.

## 1.1 القرارات التشغيلية المعتمدة
- المراحل الدراسية: ابتدائي ومتوسط وثانوي.
- الحضور: سجل مستقل لكل طالب في كل حصة دراسية.
- ولي الأمر: طلب ربط ذاتي، وحالة pending حتى اعتماد المدير؛ لا تُمنح صلاحية قراءة بيانات الطالب قبل الاعتماد.
- الرسوم: استحقاق سنوي مع دفعات جزئية متعددة وتخصيص الدفعات للاستحقاق.

## 2. مخطط النظام

[Android PWA / Browser]
        |
        | HTTPS
        v
[Vanilla JS Frontend]
        |
        | REST API + JSON
        v
[Backend API: Node.js]
        |
        +---- Authentication / Authorization
        +---- Business Services
        +---- Validation / Audit
        +---- Notification Service
        |
        v
[PostgreSQL Database]
        |
        +---- Backup / Restore
        +---- Optional Object Storage for photos and PDFs

لاحقاً:
- Android wrapper: Capacitor.
- Push: Firebase Cloud Messaging أو مزود متوافق، بعد إعداد حسابات ومفاتيح آمنة.
- ملفات: تخزين كائنات خاص/محمي، لا مجلد عام مفتوح للوثائق الحساسة.

## 3. طبقات التطبيق
### Frontend
- HTML دلالي، CSS، JavaScript ES Modules دون React/Vue/Angular.
- واجهة RTL، مكونات مشتركة مكتوبة محلياً.
- لا تحتوي الواجهة على أسرار قاعدة البيانات أو مفاتيح الخادم.
- كل العمليات الحساسة عبر API.
- لا يُسمح للواجهة بالاتصال المباشر بقاعدة PostgreSQL.

### Backend
- Node.js LTS.
- REST API موثق باستخدام OpenAPI.
- يفضّل إطار خادم خفيف ومدعوم مثل Fastify لتوحيد التحقق ومعالجة الأخطاء؛ هذا لا يفرض إطاراً على الواجهة الأمامية.
- طبقات: Routes → Controllers → Services → Repositories → PostgreSQL.
- قواعد الصلاحيات والتحقق المالي والأكاديمي تنفذ في الخادم.
- استخدام معاملات قاعدة البيانات للعمليات المركبة.

### Database
- PostgreSQL كمصدر الحقيقة المركزي.
- مفاتيح أساسية UUID.
- قيود UNIQUE وFOREIGN KEY وCHECK.
- فهارس للبحث والفلاتر.
- migrations بإصدارات محفوظة في Git.
- تخزين audit events للعمليات الحساسة.
- فصل بيانات المدرسة (school_id) في الجداول منذ البداية حتى لو كانت نسخة واحدة، لتسهيل التوسع مستقبلاً.

## 4. لماذا لا نستخدم RealmDB كمخزن مركزي؟
- قاعدة Realm محلية/مضمنة وليست خادماً مركزياً مشتركاً.
- Realm JS لا يعمل مباشرة داخل متصفح PWA العادي.
- مزامنة Atlas Device Sync القديمة لم تعد خياراً جديداً موصى به.
- وجود مدير ومدرس وطلاب وأولياء أمور من أجهزة متعددة يتطلب قاعدة مركزية وصلاحيات موثوقة على الخادم.

## 5. قاعدة محلية والعمل دون اتصال
الإصدار الأول: اتصال مطلوب لتنفيذ العمليات الحساسة. يمكن تخزين ملفات الواجهة وبعض البيانات غير الحساسة مؤقتاً.
- IndexedDB اختيار مناسب للتخزين المحلي في المتصفح/PWA عند الحاجة.
- لا تخزن كلمات المرور أو بيانات مالية حساسة محلياً دون ضرورة وتشفير مناسب.
- لا تسمح بتعديل الدرجات أو المدفوعات دون اتصال في الإصدار الأول.
- يمكن إضافة طابور مزامنة لاحقاً مع معالجة التعارضات وسجل عمليات idempotency.
- لا تعد المستخدم بأن البيانات متزامنة حتى يرد تأكيد الخادم.

## 6. Android
- ابدأ بتطبيق PWA يعمل من المتصفح ويمكن تثبيته إذا استوفى متطلبات المتصفح والاستضافة.
- بعد استقرار الويب، أنشئ Android wrapper باستخدام Capacitor.
- اختبر الإشعارات، رفع الملفات، التنقل، زر الرجوع، لوحة المفاتيح، والطباعة/مشاركة PDF على أجهزة حقيقية.
- بناء APK/AAB يحتاج بيئة بناء Android مناسبة؛ لا يُفترض أن يتم من الهاتف وحده.
- التوقيع بمفتاح إصدار خاص، وحفظ المفتاح خارج المستودع.

## 7. المصادقة والأمان
- حسابات ينشئها المدير أولاً.
- كلمات مرور مجزأة باستخدام Argon2id أو bcrypt بإعداد آمن.
- جلسات/رموز قصيرة العمر، مع refresh token آمن قابل للإبطال.
- HTTPS فقط في الإنتاج.
- حماية من brute force وتحديد معدل الطلبات.
- صلاحيات RBAC مع فحص ملكية السجل ونطاق الإسناد.
- تحقق من كل مدخل في الخادم.
- سجل تدقيق لا يسجل كلمات مرور أو أسرار.
- حماية ملفات الشهادات والمرفقات وعدم نشرها بروابط عامة قابلة للتخمين.
- لا تستخدم CORS مفتوحاً لجميع النطاقات.
- إدارة الأسرار عبر متغيرات بيئة آمنة.

## 8. نموذج بيانات مبدئي
- schools
- academic_years
- terms
- users
- roles / user_roles
- students
- parents
- student_guardians (relationship status: pending / approved / rejected / revoked; approved_by, approved_at)
- guardian_link_requests
- teachers
- education_stages (primary / middle / secondary)
- grades (linked to education_stages)
- sections
- subjects
- teacher_assignments
- rooms (اختياري)
- timetable_slots
- lessons
- attendance_records (student_id + lesson_id unique; status per lesson)
- exams
- exam_subjects
- assessments / marks
- grade_scales
- certificates
- fee_types
- student_fee_accounts (annual academic-year obligation)
- invoices (annual fee invoice / installment schedule if configured)
- payments (each partial payment is a separate immutable transaction)
- payment_allocations
- payment_allocations
- notifications
- notification_reads
- audit_logs
- attachments
- refresh_sessions

ملاحظات:
- فصل users عن students/teachers/parents حتى يمكن للحساب أن يرتبط بملف شخصي مناسب.
- علاقة ولي الأمر بالطالب عبر student_guardians.
- لا تخزن الرصيد كحقيقة منفصلة إن أمكن حسابه من القيود المالية؛ وإذا تم تخزينه مؤقتاً فيجب ضمان تحديثه داخل transaction.
- يجب تحديد سياسة حذف/أرشفة السجلات.
- كل الجداول التشغيلية المهمة تحتوي created_at وupdated_at وcreated_by عند الحاجة.

## 9. الاستضافة والتكلفة
لا تستخدم InfinityFree لاستضافة Backend إنتاجي حساس أو قاعدة بيانات مدرسة. يلزم استضافة تدعم Node.js وPostgreSQL وHTTPS ونسخاً احتياطية. يمكن بدء التطوير محلياً مجاناً، ثم تقييم خطط الاستضافة المجانية/المدفوعة وقت النشر؛ لا تعتمد على أن أي خطة مجانية دائمة أو مناسبة لبيانات الطلاب.

## 10. مراقبة وتشغيل
- health endpoint لا يكشف معلومات حساسة.
- structured logs.
- مراقبة فشل API والنسخ الاحتياطية.
- migrations قابلة للتراجع عند الإمكان.
- بيئات منفصلة: development / staging / production.
- بيانات تجريبية وهمية فقط في development.
