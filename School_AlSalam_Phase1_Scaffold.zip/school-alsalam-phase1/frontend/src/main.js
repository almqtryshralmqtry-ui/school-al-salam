const status = document.querySelector('#api-status');
document.querySelector('#year').textContent = new Date().getFullYear();

try {
  const response = await fetch('/api/health', { headers: { accept: 'application/json' } });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const result = await response.json();
  if (result.status !== 'ok') throw new Error('Unexpected health response');
  status.textContent = 'الخادم متصل ويعمل.';
  status.classList.add('ok');
} catch {
  status.textContent = 'تعذر الاتصال بالخادم. تحقق من تشغيل خدمة API.';
  status.classList.add('error');
}
