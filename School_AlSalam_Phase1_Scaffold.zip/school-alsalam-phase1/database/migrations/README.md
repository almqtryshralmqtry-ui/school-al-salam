# Database migrations

SQL migrations are versioned as `NNNN_description.sql` and are applied in filename order by `npm run db:migrate`.
The runner records successful files in `schema_migrations` and executes each file in a transaction.

No school-domain tables are created in Phase 1. Their first migration belongs to Phase 2, after the database model and constraints are reviewed against REQUIREMENTS.md. Do not add real student or financial data to development.
