import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config/env.js';

const frontendRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../frontend');
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };

export function createAppServer() {
  return createServer(async (request, response) => {
    const url = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`);
    if (request.method === 'GET' && url.pathname === '/api/health') {
      response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      response.end(JSON.stringify({ status: 'ok', service: 'school-alsalam-api' }));
      return;
    }
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      response.writeHead(405, { 'content-type': 'application/json; charset=utf-8', allow: 'GET, HEAD' });
      response.end(JSON.stringify({ error: 'METHOD_NOT_ALLOWED' }));
      return;
    }
    const relative = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
    const filePath = path.resolve(frontendRoot, `.${relative}`);
    if (!filePath.startsWith(frontendRoot + path.sep)) {
      response.writeHead(400); response.end(); return;
    }
    try {
      const body = await readFile(filePath);
      response.writeHead(200, { 'content-type': mime[path.extname(filePath)] ?? 'application/octet-stream', 'x-content-type-options': 'nosniff' });
      response.end(request.method === 'HEAD' ? undefined : body);
    } catch {
      response.writeHead(404, { 'content-type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'NOT_FOUND' }));
    }
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const server = createAppServer();
  server.listen(config.port, config.host, () => {
    console.log(`School Al-Salam API listening on http://${config.host}:${config.port}`);
  });
}
