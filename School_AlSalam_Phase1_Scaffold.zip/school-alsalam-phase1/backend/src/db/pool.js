import pg from 'pg';
import { config } from '../config/env.js';

export function createPool() {
  if (!config.databaseUrl) throw new Error('DATABASE_URL is required for database operations');
  return new pg.Pool({ connectionString: config.databaseUrl, max: config.dbPoolMax });
}
